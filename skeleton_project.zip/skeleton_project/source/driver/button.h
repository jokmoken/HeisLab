#pragma once
#include "fsm.h"
#include "elevio.h"
#include "con_load.h"

void fetch_signals_from_button_and_addqueue(Elevator* elevator);